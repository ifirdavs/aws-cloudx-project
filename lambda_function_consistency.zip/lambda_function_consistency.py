import os
import json
import logging
from typing import List, Dict, Any

import boto3
from botocore.exceptions import ClientError
import psycopg
from psycopg.rows import dict_row

# ---- ENV ----
DB_HOST = os.environ["DB_HOST"]
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_USER = os.environ["DB_USER"]
DB_PASSWORD = os.environ["DB_PASSWORD"]
DB_NAME = os.environ["DB_NAME"]
S3_BUCKET_NAME = os.environ["S3_BUCKET_NAME"]
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")

# ---- GLOBALS (reused across invocations) ----
log = logging.getLogger()
log.setLevel(os.getenv("LOG_LEVEL", "INFO"))

s3 = boto3.client("s3", region_name=AWS_REGION)
_db_conn: psycopg.Connection | None = None


# ---- DB connection helpers ----
def _connect_db() -> None:
    global _db_conn
    _db_conn = psycopg.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASSWORD,
        dbname=DB_NAME,
        sslmode="require",          # good practice for RDS
        connect_timeout=10,
    )
    _db_conn.autocommit = True

try:
    _connect_db()
except Exception as e:
    # Don't crash cold start if DB is temporarily unavailable; the first invocation will retry via _get_db_conn().
    log.warning("Initial DB connect failed; will retry on first invocation: %s", e)

def _get_db_conn() -> psycopg.Connection:
    global _db_conn
    if _db_conn is None:
        _connect_db()
        return _db_conn
    # simple health check: reconnect if closed
    if _db_conn.closed:
        _connect_db()
    return _db_conn

# ---- Core logic ----
def _fetch_images() -> List[Dict[str, Any]]:
    conn = _get_db_conn()
    with conn.cursor(row_factory=dict_row) as cur:
        cur.execute("SELECT id, name, file_extension, image_size FROM image;")
        return cur.fetchall()

def _validate_against_s3(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    inconsistent_files: List[Dict[str, str]] = []
    checked = 0

    for r in rows:
        id = r.get("id")
        name = r.get("name")
        file_extension = (r.get("file_extension") or "").strip()
        image_size = int(r.get("image_size") or 0)
        key = f"{name}.{file_extension}"
        checked += 1

        try:
            head = s3.head_object(Bucket=S3_BUCKET_NAME, Key=key)
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("404", "NoSuchKey", "NotFound"):
                inconsistent_files.append({
                    "id": id,
                    "object": key,
                    "bucket": S3_BUCKET_NAME,
                    "Error": "Object was not found in bucket",
                })
                continue
            inconsistent_files.append({
                "id": id,
                "object": key,
                "bucket": S3_BUCKET_NAME,
                "Error": f"S3 error: {code or 'Unknown'}",
            })
            continue

        actual_size = int(head.get("ContentLength", -1))
        if image_size != actual_size:
            inconsistent_files.append({
                "id": id,
                "object": key,
                "bucket": S3_BUCKET_NAME,
                "Error": "Object file size does not match with database record",
            })

    return {
        "consistent": len(inconsistent_files) == 0,
        "checked": checked,
        "inconsistent_count": len(inconsistent_files),
        "inconsistent_files": inconsistent_files,
    }

# ---- Lambda entry ----
def lambda_handler(event, context):
    log.info("SOURCE=%s; event=%s", event.get("detail-type"), event)

    try:
        rows = _fetch_images()
        result = _validate_against_s3(rows)
        return {"statusCode": 200, "body": json.dumps(result, ensure_ascii=False)}
    except Exception as e:
        log.exception("Validation failed: %s", e)
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
